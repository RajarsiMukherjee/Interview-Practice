export const ADD_COUNT = "ADD_COUNT"

export const ADD_TODO = "ADD_TODO"

export const addCount = (payload) => ({
    type : ADD_COUNT,
    payload
})

export const addTodo = (payload) => ({
    typeof :ADD_TODO,
    payload
})